# THIS FILE IS GENERATED DURING THE SCIPY BUILD
# See tools/version_utils.py for details

short_version = '1.11.4'
version = '1.11.4'
full_version = '1.11.4'
git_revision = '5e4a5e3'
commit_count = '0'
release = True

if not release:
    version = full_version
